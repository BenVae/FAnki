Follow these steps:
- Update the @plan.md (Can be a specific feature plan) with the latest uncommitted changes
- Stash and commit all the latest changes with a short and clear commit message