Follow the steps:
1. Proceed with the current plan.
  - Use claude opus for complex subtasks.
2. Ask for review after each phase.